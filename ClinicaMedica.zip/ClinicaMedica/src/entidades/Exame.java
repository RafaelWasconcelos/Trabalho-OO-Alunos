package entidades;

public class Exame {
	String tipo, 
			dataPrescrição, dataRealização, resultado, dataValidade; 
	int custo; 
	
	
	public Exame()
	{
		
	}
	public Exame(String tipo, String dataPrescrição, String dataRealização, String resultado, String dataValidade, int custo) {
		this.tipo = tipo;
		this.dataPrescrição = dataPrescrição;
		this.dataRealização = dataRealização;
		this.resultado = resultado;
		this.dataValidade = dataValidade;
		this.custo = custo;
	}
	
	public void deletarExame()
	{
		tipo = null;
		dataPrescrição=null;
		dataRealização=null;
		resultado=null; 
		dataValidade=null;
		custo = (Integer)null; 
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getDataPrescrição() {
		return dataPrescrição;
	}

	public void setDataPrescrição(String dataPrescrição) {
		this.dataPrescrição = dataPrescrição;
	}

	public String getDataRealização() {
		return dataRealização;
	}

	public void setDataRealização(String dataRealização) {
		this.dataRealização = dataRealização;
	}

	public String getResultado() {
		return resultado;
	}

	public void setResultado(String resultado) {
		this.resultado = resultado;
	}

	public String getDataValidade() {
		return dataValidade;
	}

	public void setDataValidade(String dataValidade) {
		this.dataValidade = dataValidade;
	}

	public int getCusto() {
		return custo;
	}

	public void setCusto(int custo) {
		this.custo = custo;
	}
	

}
